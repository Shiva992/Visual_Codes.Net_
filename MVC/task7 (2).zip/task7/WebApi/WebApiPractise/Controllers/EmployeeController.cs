﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using WebApiPractise.Models;
using System.Data.Entity;

namespace WebApiPractise.Controllers
{
    public class EmployeeController : ApiController
    {
        //public string[] Employee = { "Amit", "Nikki", "Vaibhav", "Ayush" };

        //[HttpGet]
        //public string[] GetEmployee()
        //{
        //    return Employee;
        //}
        //public string GetEmployeeofIndex(int id)
        //{
        //    return Employee[id];
        //}

       
    }
}
