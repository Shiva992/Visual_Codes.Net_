﻿namespace MVC.Controllers
{
    public class Table_1
    {
    }
}